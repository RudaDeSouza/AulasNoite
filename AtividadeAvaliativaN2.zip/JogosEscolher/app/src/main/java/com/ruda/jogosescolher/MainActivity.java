package com.ruda.jogosescolher;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView btnPlayVelha, btnPlayQuebra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPlayQuebra = findViewById(R.id.btnPlayQuebra);
        btnPlayVelha = findViewById(R.id.btnPlayVelha);
        btnPlayQuebra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirQuebra();
            }
        });
        btnPlayVelha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVelha();
            }
        });
    }
    private void abrirVelha() {
        Intent janela1 = new Intent(this, JogoVelha.class);
        startActivity(janela1);
        finish();
    }
    private void abrirQuebra() {
        Intent janela2 = new Intent(this, QuebraCabeca.class);
        startActivity(janela2);
        finish();
    }
}