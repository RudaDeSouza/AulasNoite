package com.ruda.meumenu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //1ª Etapa:
    private ListView lista;
    private String[] itens = {"HTML5","CSS","SASS","JavaScript","NodeJs","AngularJs","Ruby","React","JQuery"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //2ª Etapa: Criar um adaptador para servir de ligação entre o Array e o elemento ListView no XML
        lista = findViewById(R.id.lista);

        /*3ª Etapa: Criar um adaptador para servir de ligação entre o Array e o elemento
        ListView no XML
        O adaptador vem do atributo ArrayAdapter
        android.R.layout.simple_list_item_1: define o tipo de lista, ou seja, uma lista simples no Layout atual - item 1;
        android.R.id.text1,itens: Mapeamento que define os tipos de valores da lista
        */
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
        android.R.layout.simple_list_item_1, android.R.id.text1,itens);

        //4ªEtapa: Adicionar o adapter
        lista.setAdapter(adapter);

        //5 Etapa: Print na tela em Toast indicando qual o item que foi clicado.
        //eventos: setOnItemClickListener e onItemClick
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
           switch(i)
           {
               case 0:
                   openHTML();
                   break;
               case 3:
                   openjavaScript();
           }
            }
        });

    }
    public void openHTML() {
        Intent janelaHTML = new Intent(this, CursoHTML.class);
        startActivity(janelaHTML);
        finish();
    }
    public void openjavaScript() {
        Intent janelaJavaScript = new Intent(this, CursoJavaScript.class);
        startActivity(janelaJavaScript);
        finish();
    }
}