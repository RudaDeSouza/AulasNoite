package com.ruda.meuslinks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnPinterest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnPinterest = findViewById(R.id.btnPinterest);

        btnPinterest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pin();
            }
        });
    }
    public void pin(){
        Intent janelaP = new Intent(Intent.ACTION_VIEW, Uri.parse("https://br.pinterest.com/"));
        startActivity(janelaP);
    }
}