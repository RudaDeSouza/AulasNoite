package com.ruda.sensoresn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class Alarme extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarme);
        MainActivity.mp.start();
    }
    @Override
    public void onBackPressed() {
        //tentei usar o mp.reset() e não funcionou :(
        MainActivity.mp.pause();
        abrir();
    }
    public void abrir(){
        Intent janela = new Intent(this,SensorProximidade.class);
        startActivity(janela);
    }
}