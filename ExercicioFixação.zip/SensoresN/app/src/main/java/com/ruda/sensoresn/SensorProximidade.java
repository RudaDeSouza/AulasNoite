package com.ruda.sensoresn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

//declaração da classe implements com a abstração do SensorEventListener
public class SensorProximidade extends AppCompatActivity implements SensorEventListener {
    //declaração dos objetos
    private TextView resposta;
    private Sensor proximidade;
    private SensorManager medir;
    private Button btnVoltar, btnLuminosidade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_proximidade);

        //mapeamento de todos os objetos do Layout
        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        resposta = findViewById(R.id.visual);
        btnLuminosidade = findViewById(R.id.btnLuminosidade);
        btnVoltar = findViewById(R.id.btnVoltar);

        //eventos de botões
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

        btnLuminosidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirLuminosidade();
            }
        });

    }

    public void abrirAlarme() {
        Intent alarme = new Intent(this,Alarme.class);
        startActivity(alarme);
    }

    //método de abertura das activities
    public void abrirVoltar() {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);
    }

    public void abrirLuminosidade() {
        Intent janelaLuz = new Intent(this, SensorLuminosidade.class);
        startActivity(janelaLuz);
    }

    //chamada de CallBacks, que tem a função de definir o comportamento e do ciclo de vida das activities
    //é o onResume e o onPause
    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    protected void onPause() {
        medir.unregisterListener(this, proximidade);
        super.onPause();
    }

    //método onSensorChanged que ocorre quando é executado ou modificado algum tipo de evento relacionado ao sensor especificado (proximidade/proximity)
    //se o valor do evento for igual a 0, é porque estamos próximos ao sensor, senão, estamos afastados.
    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.values[0] == 0)
        {
            getWindow().getDecorView().setBackgroundColor(Color.MAGENTA);
            resposta.setText("PRÓXIMO");
            abrirAlarme();
        }
        else
        {
            getWindow().getDecorView().setBackgroundColor(Color.CYAN);
            resposta.setText("AFASTADO");
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}