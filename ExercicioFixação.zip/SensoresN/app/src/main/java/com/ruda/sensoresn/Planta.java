package com.ruda.sensoresn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class Planta extends AppCompatActivity {
private WebView regando;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planta);

        WebSettings gif = regando.getSettings();
        gif.setJavaScriptEnabled(true);
        String caminho = "file:android_asset/rega.gif";

    }
}