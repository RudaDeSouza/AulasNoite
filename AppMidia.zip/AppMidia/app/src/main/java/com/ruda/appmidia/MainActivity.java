package com.ruda.appmidia;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {
    private Button btnPlay;
    private SeekBar posicao;
    private MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPlay = findViewById(R.id.btnPlay);
        mp = MediaPlayer.create(this, R.raw.punky);
        posicao = findViewById(R.id.posicao);
    }

    public void playMusica(View view){
        if(!mp.isPlaying()) {
            mp.start();
            btnPlay.setBackgroundResource(R.drawable.stop);
        } else {
            mp.pause();
            btnPlay.setBackgroundResource(R.drawable.play);
        }
    }
}