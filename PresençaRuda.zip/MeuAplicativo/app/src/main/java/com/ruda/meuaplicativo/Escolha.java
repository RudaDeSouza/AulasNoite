package com.ruda.meuaplicativo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class Escolha extends AppCompatActivity {
    private TextView resposta;
    private Button btnSom, btnTeaser;
    private WebView imagem1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolha);
        resposta = findViewById(R.id.resposta);
        btnSom = findViewById(R.id.btnSom);
        btnTeaser = findViewById(R.id.btnTeaser);
        imagem1 = findViewById(R.id.imagem1);

        String recebe = getIntent().getStringExtra("dados");
        resposta.setText(recebe);

        btnSom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMusica();
            }
        });

        btnTeaser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirTeaser();
            }
        });
    }

    public void abrirTeaser() {
        Intent janelaT = new Intent(this, Teaser.class);
        startActivity(janelaT);
    }
    public void abrirMusica() {
        Intent janelaM = new Intent(this, Som.class);
        startActivity(janelaM);
    }
}